import React from "react";

const Main = () => {
  return <h1>Главная страница</h1>;
};

export default Main;
